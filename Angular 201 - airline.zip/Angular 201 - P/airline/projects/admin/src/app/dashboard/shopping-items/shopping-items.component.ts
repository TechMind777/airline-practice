import { Component } from '@angular/core';

@Component({
  selector: 'app-shopping-items',
  templateUrl: './shopping-items.component.html',
  styleUrl: './shopping-items.component.scss'
})
export class ShoppingItemsComponent {

}
