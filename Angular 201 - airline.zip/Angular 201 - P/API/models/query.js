const _select = (table, obj)=>{}
const _insert = (table, obj)=>{}
const _update = (table, obj)=>{}
const _delete = (table, obj)=>{}